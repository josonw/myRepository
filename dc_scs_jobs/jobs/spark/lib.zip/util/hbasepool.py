# coding: utf-8

""" create a connection pool for hbase
"""

import happybase

# hbase thrift config
HBASE_THRIFT_HOST = "192.168.0.91"
HBASE_THRIFT_PORT = "9090"
THRIFT_PROTOCOL = "compact"

# the maximum number of concurrently open connections
POOL_SIZE = 16

pool = happybase.ConnectionPool(POOL_SIZE,
                                host=HBASE_THRIFT_HOST,
                                port=HBASE_THRIFT_PORT,
                                protocol=THRIFT_PROTOCOL)

def getHbasePool():
    return pool
 
